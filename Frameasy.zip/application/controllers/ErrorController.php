<?php

defined('CONTROLLER_PATH') or exit('Acceso denegado');

// Incluimos el modelo en el controlador...
Load::model('DefaultModel');
// Incluimos las librerías en el controlador...

/**
 * Controlador de errores.
 */
class ErrorController extends DefaultModel {

    /**
     * Constructor de la clase.
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Maneja las notificaciones y muestra la página de error por defecto.
     */
    private function manejarNotificacion() {
        if (isset($_SESSION['notificacion'])) {
            $data['notificacion'] = $_SESSION['notificacion'];
            unset($_SESSION['notificacion']);
            return $data['notificacion'];
        }
        return null;
    }

    /**
     * Acción principal del controlador.
     */
    public function index() {
        $data['notificacion'] = $this->manejarNotificacion();
        Load::view("incl/navbar", $data);
        Load::view("default_error", $data);
        Load::view("incl/aside", $data);
        Load::view("incl/footer", $data);
    }

}
