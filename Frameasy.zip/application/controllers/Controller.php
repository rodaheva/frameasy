<?php

/**
 * Controlador principal para la gestión de las acciones y vistas.
 * Hereda del modelo "DefaultModel".
 */
defined('CONTROLLER_PATH') or exit('Acceso denegado');

# Incluimos el modelo en el controlador...
Load::model('DefaultModel');
# Incluimos las librerías en el controlador...

class Controller extends DefaultModel {

    /**
     * Constructor de la clase.
     * Llama al constructor del modelo "DefaultModel".
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Método privado para manejar las notificaciones.
     * Si existe una notificación en la sesión, la guarda en la variable "data" y la elimina de la sesión.
     * Retorna la notificación o null si no hay ninguna.
     */
    private function manejarNotificacion() {
        if (isset($_SESSION['notificacion'])) {
            $data['notificacion'] = $_SESSION['notificacion'];
            unset($_SESSION['notificacion']);
            return $data['notificacion'];
        }
        return null;
    }

    /**
     * Acción principal del controlador.
     * Carga las vistas necesarias, pasando los datos de la notificación.
     */
    public function index() {
        $data['notificacion'] = $this->manejarNotificacion();
        Load::view("incl/navbar", $data);
        Load::view("default_view", $data);
        Load::view("incl/aside", $data);
        Load::view("incl/footer", $data);
    }

}
