<!DOCTYPE html>
<html>
    <head>
        <title>Error 404</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <style>
            body {
                background-color: #f8f9fa;
            }
            .error-container {
                max-width: 500px;
                margin: auto;
                margin-top: 50px;
                text-align: center;
            }
            h1 {
                font-size: 6rem;
                color: #dc3545;
                margin-bottom: 0;
            }
            p {
                font-size: 1.5rem;
                color: #495057;
            }
        </style>
    </head>
    <body>
        <div class="error-container">
            <h1>404</h1>
            <p>Lo sentimos, la página que buscas no se encuentra disponible.</p>
            <a href="/" class="btn btn-primary mt-3">Ir a la página principal</a>
        </div>
    </body>
</html>
