<?php

/**
 * Clase que proporciona funciones útiles para el sistema.
 */
class System {

    /**
     * Crea un mensaje de alerta.
     *
     * @param string $header El encabezado del mensaje.
     * @param string $message El contenido del mensaje.
     * @param string $type El tipo de alerta (success, info, warning, danger).
     * @return string El mensaje de alerta generado.
     */
    public static function createMessage($header, $message, $type) {
        return "<div align='center' class='alert alert-{$type}' role='alert'>
                    <b>{$header}</b> {$message}
                </div>";
    }

    /**
     * Extrae un atributo de la URL.
     *
     * @return string|null El valor del atributo extraído de la URL, o null si no se proporciona.
     */
    public static function extractAttributeFromUrl() {
        $url = filter_input(INPUT_GET, 'url', FILTER_SANITIZE_URL);

        if (!$url) {
            return null;
        }

        $path = parse_url($url, PHP_URL_PATH);
        $segments = array_filter(explode('/', $path));

        return count($segments) >= 3 ? $segments[2] : null;
    }

}

// Crear una nueva instancia de la clase "System" para utilizar las funciones proporcionadas
$system = new System();
