<?php

// Definición de rutas
define('CONTROLLER_PATH', dirname(__FILE__) . '/controllers/');
define('MODEL_PATH', dirname(__FILE__) . '/models/');
define('VIEWS_PATH', dirname(__FILE__) . '/views/');

// Constantes de configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'conalac');
define('DB_USER', 'root');
define('DB_PASS', '');

// Constantes de la aplicación
define('BASE_URL', 'http://localhost/tarea/');

// Configuración de correo electrónico
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'mi_correo@gmail.com');
define('SMTP_PASS', 'mi_contraseña');

class Load {

    /**
     * Método estático para cargar una vista.
     * Se pasan los datos a la vista como un arreglo asociativo.
     */
    public static function view($view, $data = []) {
        extract($data);
        include "application/views/$view.php";
    }

    /**
     * Método estático para cargar un modelo.
     */
    public static function model($model) {
        require_once "application/models/$model.php";
    }

    /**
     * Método estático para cargar una librería.
     */
    public static function library($library) {
        require_once "application/libs/$library.php";
    }

    /**
     * Método estático para cargar una plantilla.
     * Retorna el contenido de la plantilla como una cadena de texto.
     */
    public static function template($template) {
        $path = file_get_contents("application/views/templates/$template.html");
        return $path;
    }

}
