<?php

/**
 * Clase para la gestión de la base de datos.
 */
class Database {

    // Variables para la conexión a la base de datos
    private $DB_HOST = DB_HOST;
    private $DB_USER = DB_USER;
    private $DB_PASS = DB_PASS;
    private $DB_NAME = DB_NAME;
    // Objeto de conexión a la base de datos
    public $con;

    /**
     * Constructor de la clase.
     * Establece la conexión a la base de datos al instanciar el objeto.
     */
    public function __construct() {
        $this->connectToDB();
    }

    /**
     * Método protegido para establecer la conexión a la base de datos.
     * Utiliza los valores de las variables de conexión.
     * En caso de error, muestra un mensaje y termina la ejecución.
     */
    protected function connectToDB() {
        $this->con = new mysqli($this->DB_HOST, $this->DB_USER, $this->DB_PASS, $this->DB_NAME);

        if ($this->con->connect_error) {
            die("Error de conexión a la base de datos: " . $this->con->connect_error);
        }
    }

    /**
     * Destructor de la clase.
     * Cierra la conexión a la base de datos al destruir el objeto.
     */
    public function __destruct() {
        $this->con->close();
    }

}
