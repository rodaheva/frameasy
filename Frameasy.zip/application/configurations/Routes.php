<?php

/**
 * Clase que maneja el enrutamiento de la aplicación.
 * Redirige las peticiones a los controladores y métodos correspondientes.
 */
class Routes {

    public function __construct() {
        // Verificar si se proporciona una URL en la variable $_GET['url']
        if (!isset($_GET['url'])) {
            // Si no hay URL, redirigir al usuario a la página de inicio utilizando la constante BASE_URL
            header("Location: " . BASE_URL . "controller/");
            exit;
        }

        // Obtener la URL proporcionada y dividirla en partes utilizando la función explode
        $url = $_GET['url'];
        $ruta = explode('/', $url);

        // Verificar que se haya proporcionado un controlador válido
        if (empty($ruta[0])) {
            // Si no se proporciona un controlador válido, redirigir al usuario a la página de inicio utilizando la constante BASE_URL
            header("Location: " . BASE_URL . "controller/");
            exit;
        }

        // Establecer el nombre del controlador y el método que se deben cargar
        $controllerName = ucfirst($ruta[0]);
        $method = empty($ruta[1]) ? 'index' : $ruta[1];

        // Construir la ruta del archivo del controlador
        $controllerPath = './application/controllers/' . $controllerName . '.php';

        // Verificar si el archivo del controlador existe en la ruta proporcionada
        if (!file_exists($controllerPath)) {
            // Si el archivo del controlador no existe, cargar el controlador de error predeterminado
            require_once './application/controllers/ErrorController.php';
            $controllerName = 'ErrorController';
            $method = 'index';
            $controllerPath = './application/controllers/' . $controllerName . '.php';
        }

        // Cargar el archivo del controlador y crear una nueva instancia del controlador
        require_once $controllerPath;
        $controller = new $controllerName();

        // Verificar que el método a cargar exista en el controlador
        if (!method_exists($controller, $method)) {
            // Si el método no existe en el controlador, establecer el método en "index"
            $method = 'index';
        }

        // Llamar al método del controlador para generar la salida de la aplicación
        $controller->$method();
    }

}

// Crear una nueva instancia de la clase "Routes" para iniciar el enrutamiento de la aplicación
$ruta = new Routes();
?>
