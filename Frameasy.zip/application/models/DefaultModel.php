<?php

defined('MODEL_PATH') or exit('Acceso Denegado');

require_once 'application/configurations/Database.php';

/**
 * Clase modelo por defecto.
 */
class DefaultModel extends Database {

    /**
     * Constructor de la clase.
     */
    function __construct() {
        parent::__construct();
    }

    /**
     * Valida el inicio de sesión utilizando los datos proporcionados.
     *
     * @param string $usuario Nombre de usuario.
     * @param string $contrasena Contraseña del usuario.
     * @return bool True si la validación es exitosa, false de lo contrario.
     */
    protected function validarInicioSesion($usuario, $contrasena) {
        // Aplicamos seguridad a los datos recibidos
        $usuario = mysqli_real_escape_string($this->con, $usuario);
        $contrasena = mysqli_real_escape_string($this->con, $contrasena);
        
        // Creamos la consulta SQL
        $sql = "SELECT * FROM `usuarios` WHERE `usuario` = '$usuario' AND `contrasena` = '$contrasena'";
        
        // Ejecutamos la consulta SQL
        $query = mysqli_query($this->con, $sql);
        
        // Almacenamos los datos en un arreglo
        $cuenta = mysqli_fetch_assoc($query);
        
        // Validamos que existan datos
        if (!empty($cuenta)) {
            return true;
        }
        
        return false;
    }

}
