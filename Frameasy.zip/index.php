<?php

session_start();

class Application {

    public function __construct() {

        // Definimos la zona horaria...
        date_default_timezone_set('America/Bogota');

        // Definimos el tipo de moneda...
        setlocale(LC_MONETARY, 'en_US');
    }

    public function run() {
        // Incluimos los archivos necesarios...
        include_once 'application/configurations/Config.php';
        include_once 'application/configurations/System.php';
        include_once 'application/configurations/Routes.php';
    }

}

$app = new Application();
$app->run();
